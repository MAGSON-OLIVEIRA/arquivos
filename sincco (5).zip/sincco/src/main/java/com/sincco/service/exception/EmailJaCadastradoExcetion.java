package com.sincco.service.exception;

public class EmailJaCadastradoExcetion  extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public EmailJaCadastradoExcetion (String message){
		super(message);
	}
	
}
