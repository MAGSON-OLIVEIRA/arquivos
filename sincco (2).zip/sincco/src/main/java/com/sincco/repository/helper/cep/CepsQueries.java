package com.sincco.repository.helper.cep;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sincco.model.CepServico;
import com.sincco.repository.filter.CepFilter;

public interface CepsQueries {
	public Page<CepServico> filtrar(CepFilter filtro, Pageable pageable);

}
