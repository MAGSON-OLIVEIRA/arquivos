package com.sincco.repository.filter;

public class CepFilter {
	
	private Long id;
	private String cep;

	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}
