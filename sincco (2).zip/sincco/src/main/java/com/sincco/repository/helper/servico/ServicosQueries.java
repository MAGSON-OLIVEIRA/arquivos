package com.sincco.repository.helper.servico;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sincco.model.Servico;
import com.sincco.repository.filter.ServicoFilter;

public interface ServicosQueries {
	public Page<Servico> filtrar(ServicoFilter filtro, Pageable pageable);

}
