package com.sincco.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sincco.model.CepServico;
import com.sincco.repository.CepsServicos;

@Service
public class CadastroCepServicoService {
	@Autowired
	private CepsServicos cepsServicos;
	
	@Transactional
	public void salvar(CepServico cepServico){
		cepsServicos.save(cepServico);
	}
	
	@Transactional
	public List<CepServico> lista(){
		return cepsServicos.findAll();
	}
	
	@Transactional
	public void deletar(CepServico cepServico){
		cepsServicos.delete(cepServico);
	}
	
	public CepServico pesquisaPorId(Long id){
		return cepsServicos.findOne(id);
	}

	public List<CepServico> findByCepStartingWithIgnoreCase(String cep) {
		return cepsServicos.findByCepStartingWithIgnoreCase(cep);
	}

	
}
