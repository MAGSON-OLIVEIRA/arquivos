package com.sincco.model.validation.group;

public interface CpfGroup {

}
