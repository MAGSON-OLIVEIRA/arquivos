CREATE TABLE usuario (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    senha character varying(100) NOT NULL,
    cpfCnpj character varying(15) NOT NULL,
    telefoneCelular character varying(20),
    telefoneFixo character varying(20),
    tipoPessoa character varying(15) NOT NULL,
    ativo boolean default true
);

ALTER TABLE public.usuario OWNER TO postgres;

CREATE SEQUENCE usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.usuario_id_seq OWNER TO postgres;

ALTER SEQUENCE usuario_id_seq OWNED BY usuario.id;

ALTER TABLE ONLY usuario ALTER COLUMN id SET DEFAULT nextval('usuario_id_seq'::regclass);


INSERT INTO usuario ( id, nome, email, senha, cpfcnpj, telefonecelular, telefonefixo, tipopessoa, ativo) VALUES ( 1, 'Admin', 'admin@admin.com', '$2a$10$g.wT4R0Wnfel1jc/k84OXuwZE02BlACSLfWy6TycGPvvEKvIm86SG', '00000000000', NULL, NULL, 'FISICA', true);
INSERT INTO usuario (id, nome, email, senha, cpfcnpj, telefonecelular, telefonefixo, tipopessoa, ativo) VALUES (8, 'MAGSON DIAS', 'magson@bbprevidencia.com.br', '$2a$10$pdNLXoQr6Dqj9WuOmr6azuBn.oSMqaPioZR4m1DVDneblHtzjiRye', '00704907160', '(61) 98138-4489', null, 'FISICA', true);

SELECT pg_catalog.setval('usuario_id_seq', 1, false);

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);



CREATE TABLE permissao (
    id integer NOT NULL,
    nome character varying(100) NOT NULL
);

ALTER TABLE ONLY permissao
    ADD CONSTRAINT permissao_pkey PRIMARY KEY (id);


ALTER TABLE public.permissao OWNER TO postgres;

CREATE SEQUENCE permissao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.permissao_id_seq OWNER TO postgres;

ALTER SEQUENCE permissao_id_seq OWNED BY permissao.id;

ALTER TABLE ONLY permissao ALTER COLUMN id SET DEFAULT nextval('permissao_id_seq'::regclass);

INSERT INTO permissao (id, nome) VALUES (1, 'CADASTRA_USUARIO');
INSERT INTO permissao (id, nome) VALUES (2, 'CADASTRA_PRODUTO');
INSERT INTO permissao (id, nome) VALUES (4, 'CADASTRA_SERVICO');
INSERT INTO permissao (id, nome) VALUES (3, 'CADASTRA_TIPOLOGIA');
INSERT INTO permissao (id, nome) VALUES (5, 'CADASTRA_CEP');
INSERT INTO permissao (id, nome) VALUES (6, 'CADASTRA_SERVICO_PESQUISA');
INSERT INTO permissao (id, nome) VALUES (7, 'CADASTRA_SERVICO_PESQUISA_CL');
    

CREATE TABLE grupo (
    id integer NOT NULL,
    nome character varying(100) NOT NULL
);

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_pkey PRIMARY KEY (id);

    
    ALTER TABLE public.grupo OWNER TO postgres;

CREATE SEQUENCE grupo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.grupo_id_seq OWNER TO postgres;

ALTER SEQUENCE grupo_id_seq OWNED BY grupo.id;

ALTER TABLE ONLY grupo ALTER COLUMN id SET DEFAULT nextval('grupo_id_seq'::regclass);

INSERT INTO grupo (id, nome) VALUES (1, 'cliente');
INSERT INTO grupo (id, nome) VALUES (2, 'usuario');

CREATE TABLE usuario_grupo (
    id_usuario integer NOT NULL,
    id_grupo integer NOT NULL
);

ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_pkey PRIMARY KEY (id_usuario, id_grupo);

ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_usuario_fk FOREIGN KEY (id_usuario) REFERENCES usuario(id);
    
ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_grupo_fk FOREIGN KEY (id_grupo) REFERENCES grupo(id);
    

CREATE TABLE grupo_permissao (
    id_grupo integer NOT NULL,
    id_permissao integer NOT NULL
);

ALTER TABLE ONLY grupo_permissao
    ADD CONSTRAINT grupo_permissao_pkey PRIMARY KEY (id_grupo, id_permissao);

ALTER TABLE ONLY grupo_permissao
    ADD CONSTRAINT grupo_permissao_grupo_fk FOREIGN KEY (id_grupo) REFERENCES grupo(id);
    
ALTER TABLE ONLY grupo_permissao
    ADD CONSTRAINT grupo_permissao_permisao_fk FOREIGN KEY (id_permissao) REFERENCES permissao(id);


INSERT INTO usuario_grupo (id_usuario, id_grupo) VALUES (1, 2);
INSERT INTO usuario_grupo (id_usuario, id_grupo) VALUES (8, 1);


INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 1);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 2);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 3);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 4);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 5);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (1, 4);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (1, 7);
INSERT INTO grupo_permissao (id_grupo, id_permissao) VALUES (2, 6);


