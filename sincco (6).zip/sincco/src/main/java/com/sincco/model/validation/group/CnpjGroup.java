package com.sincco.model.validation.group;

public interface CnpjGroup {

}
