package com.sincco.service.exception;

public class NomeEstiloJaCadastradoExcetion extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public NomeEstiloJaCadastradoExcetion (String message){
		super(message);
	}

}
