package com.sincco.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sincco.model.Grupo;

public interface Grupos extends JpaRepository<Grupo, Long> {

}
