package com.sincco.service.exception;

public class CpfCnpjJaCadastradoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CpfCnpjJaCadastradoException(String message){
		super(message);
		
	}
	
	
	
}
